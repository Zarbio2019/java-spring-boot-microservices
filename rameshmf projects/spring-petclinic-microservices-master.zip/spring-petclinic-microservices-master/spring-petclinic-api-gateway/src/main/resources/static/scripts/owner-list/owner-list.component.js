'use strict';

angular.module('ownerList')
    .component('ownerList', {
        templateUrl: 'scripts/owner-list/owner-list.template.html',
        controller: 'OwnerListController'
    });
